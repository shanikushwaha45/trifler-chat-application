import { useEffect, useState } from "react";
import AuthContextValue from "./authContextValue";
import {
  deleteCurrentUser,
  updateUserProfile,
} from "../services/userService";

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() =>
    localStorage.getItem("chatconnect_token"),
  );
  const [user, setUser] = useState(() => {
    const storedUser = localStorage.getItem("chatconnect_user");
    if (!storedUser) return null;
    try {
      const parsedUser = JSON.parse(storedUser);
      if (!parsedUser || typeof parsedUser !== "object" || Array.isArray(parsedUser)) {
        throw new Error("Saved chat profile is not a user object.");
      }
      return parsedUser;
    } catch (error) {
      console.error("Could not restore the saved chat profile.", error);
      localStorage.removeItem("chatconnect_user");
      return null;
    }
  });

  useEffect(() => {
    if (token) {
      localStorage.setItem("chatconnect_token", token);
    } else {
      localStorage.removeItem("chatconnect_token");
    }
  }, [token]);

  useEffect(() => {
    if (user) {
      localStorage.setItem("chatconnect_user", JSON.stringify(user));
    } else {
      localStorage.removeItem("chatconnect_user");
    }
  }, [user]);

  function login(tokenValue, userValue = null) {
    console.info("[Trifler local auth] Session started", {
      name: userValue?.name || "",
      email: userValue?.email || "",
      mode: "local demo; credentials are not verified by a server",
    });
    setToken(tokenValue);
    setUser(userValue);
  }

  async function updateProfile(profileValue) {
    const name = profileValue?.name?.trim();
    const email = profileValue?.email?.trim();
    if (!name || !email) {
      throw new Error("A display name and email address are required.");
    }

    const responseProfile = await updateUserProfile({ name, email });
    const updatedUser = {
      ...user,
      ...(responseProfile && typeof responseProfile === "object" ? responseProfile : {}),
      name,
      email,
    };
    setUser(updatedUser);
  }

  async function deleteAccount() {
    await deleteCurrentUser();
    console.info("[Trifler auth] Account deleted.");
    setToken(null);
    setUser(null);
  }

  function logout() {
    console.info("[Trifler local auth] Session ended", {
      name: user?.name || "",
      email: user?.email || "",
    });
    setToken(null);
    setUser(null);
  }

  return (
    <AuthContextValue.Provider
      value={{
        token,
        user,
        isLoading: false,
        login,
        updateProfile,
        deleteAccount,
        logout,
      }}
    >
      {children}
    </AuthContextValue.Provider>
  );
}
