import { useCallback, useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import {
  createDirectConversation as createDirectConversationRequest,
  getConversations,
} from "../services/chatService";
import { createGroup as createGroupRequest } from "../services/groupService";
import { isBackendEnabled } from "../services/api";
import ChatContextValue from "./chatContextValue";

const conversationsStorageKey = "trifler_conversations";
const legacyConversationsStorageKey = "trifler_demo_conversations";

function readConversations() {
  localStorage.removeItem(legacyConversationsStorageKey);
  const savedConversations = localStorage.getItem(conversationsStorageKey);
  if (!savedConversations) return [];

  try {
    const conversations = JSON.parse(savedConversations);
    if (Array.isArray(conversations)) return conversations;
    throw new Error("Saved conversations are not a list.");
  } catch (error) {
    console.error("[Trifler local chat] Could not restore conversations.", error);
    localStorage.removeItem(conversationsStorageKey);
    return [];
  }
}

export function ChatProvider({ children }) {
  const { user } = useAuth();
  const [conversations, setConversations] = useState(readConversations);

  useEffect(() => {
    if (conversations.length > 0) {
      localStorage.setItem(conversationsStorageKey, JSON.stringify(conversations));
    } else {
      localStorage.removeItem(conversationsStorageKey);
    }
    console.info("[Trifler local chat] Conversations and messages", conversations);
  }, [conversations]);

  useEffect(() => {
    if (!isBackendEnabled) return undefined;

    let isCurrent = true;
    getConversations()
      .then((serverConversations) => {
        if (!isCurrent || !Array.isArray(serverConversations)) return;
        setConversations(serverConversations);
      })
      .catch((error) => {
        console.error("[Trifler chat] Could not load conversations from backend.", error);
      });

    return () => {
      isCurrent = false;
    };
  }, []);

  const markConversationRead = useCallback((conversationId) => {
    setConversations((current) =>
      current.map((conversation) =>
        conversation.id === conversationId && conversation.unread
          ? { ...conversation, unread: 0 }
          : conversation,
      ),
    );
  }, []);

  const clearConversations = useCallback(() => {
    setConversations([]);
    localStorage.removeItem(conversationsStorageKey);
    localStorage.removeItem(legacyConversationsStorageKey);
    console.info("[Trifler local chat] Local conversations cleared.");
  }, []);

  // Add incoming STOMP messages to local state so the existing UI can render them.
  const receiveMessage = useCallback((conversationId, incomingMessage) => {
    const payload = incomingMessage?.message || incomingMessage;
    if (!conversationId || typeof payload?.text !== "string" || !payload.text.trim()) {
      console.error("[Trifler chat] Ignored an invalid incoming message.", incomingMessage);
      return;
    }

    const message = {
      id: payload.id || `${Date.now()}-${Math.random()}`,
      text: payload.text,
      time: payload.time || new Intl.DateTimeFormat("en", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      }).format(new Date()),
      from: payload.from || "them",
      author: payload.author,
    };

    setConversations((current) =>
      current.map((conversation) => {
        if (conversation.id !== conversationId) return conversation;
        if (conversation.messages.some((item) => item.id === message.id)) return conversation;
        return {
          ...conversation,
          messages: [...conversation.messages, message],
          preview: message.text,
          time: "Now",
        };
      }),
    );
    console.info("[Trifler chat] Incoming message received", {
      conversationId,
      message,
    });
  }, []);

  const sendMessage = useCallback((conversation, text) => {
    const messageText = text.trim();
    if (!conversation || !messageText) return null;

    const message = {
      id: `${Date.now()}-${Math.random()}`,
      text: messageText,
      time: new Intl.DateTimeFormat("en", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      }).format(new Date()),
      from: "me",
    };

    setConversations((current) =>
      current.map((item) =>
        item.id === conversation.id
          ? {
              ...item,
              messages: [...item.messages, message],
              preview: messageText,
              time: "Now",
            }
          : item,
      ),
    );
    console.info("[Trifler chat] Message created locally", {
      conversationId: conversation.id,
      conversationName: conversation.name,
      message,
    });
    return message;
  }, []);

  const createGroup = useCallback((name) => {
    const groupName = name.trim();
    if (!groupName) return null;

    const slug = groupName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "group";
    const group = {
      id: `${slug}-${Date.now()}`,
      name: groupName,
      initials: groupName.slice(0, 2).toUpperCase(),
      color: "blue",
      category: "group",
      members: "1 member",
      memberList: [user?.name || "Your profile"],
      preview: "Group created",
      time: "Now",
      unread: 0,
      messages: [],
    };

    setConversations((current) => [...current, group]);
    console.info("[Trifler groups] Group created locally", group);
    createGroupRequest(group).catch((error) => {
      console.error("[Trifler groups] Could not create group on backend.", error);
    });
    return group;
  }, [user?.name]);

  const createDirectConversation = useCallback((name) => {
    const contactName = name.trim();
    if (!contactName) return null;

    const existingConversation = conversations.find(
      (conversation) =>
        conversation.category === "direct" &&
        conversation.name.trim().toLowerCase() === contactName.toLowerCase(),
    );
    if (existingConversation) return existingConversation;

    const slug = contactName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "contact";
    const conversation = {
      id: `${slug}-${Date.now()}`,
      name: contactName,
      initials: contactName
        .split(/\s+/)
        .map((part) => part[0])
        .join("")
        .slice(0, 2)
        .toUpperCase(),
      color: "lavender",
      category: "direct",
      online: false,
      preview: "Start a conversation",
      time: "Now",
      unread: 0,
      messages: [],
    };

    setConversations((current) => [...current, conversation]);
    console.info("[Trifler chats] One-to-one conversation created locally", {
      conversationId: conversation.id,
      contactName: conversation.name,
    });
    createDirectConversationRequest(conversation).catch((error) => {
      console.error("[Trifler chats] Could not create direct conversation on backend.", error);
    });
    return conversation;
  }, [conversations]);

  return (
    <ChatContextValue.Provider
      value={{
        conversations,
        clearConversations,
        markConversationRead,
        receiveMessage,
        sendMessage,
        createGroup,
        createDirectConversation,
      }}
    >
      {children}
    </ChatContextValue.Provider>
  );
}