import { MessageCircle, UserRound, X } from "lucide-react";
import { useState } from "react";

export default function StartDirectChatModal({ isOpen, onClose, onStart }) {
  const [name, setName] = useState("");

  if (!isOpen) return null;

  function closeModal() {
    setName("");
    onClose();
  }

  function submitConversation(event) {
    event.preventDefault();
    const contactName = name.trim();
    if (!contactName) return;
    onStart(contactName);
    setName("");
  }

  return (
    <div
      className="modal-backdrop"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) closeModal();
      }}
    >
      <section
        className="new-chat-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="start-direct-chat-title"
      >
        <div className="modal-heading">
          <div>
            <span className="modal-kicker">ONE-TO-ONE CHAT</span>
            <h2 id="start-direct-chat-title">Start a conversation</h2>
          </div>
          <button
            className="icon-button"
            type="button"
            aria-label="Close"
            onClick={closeModal}
          >
            <X size={19} />
          </button>
        </div>
        <p>Enter the name of the person you want to chat with.</p>
        <form className="auth-form" onSubmit={submitConversation}>
          <label>
            <span>Contact name</span>
            <span className="direct-chat-name-field">
              <UserRound size={17} aria-hidden="true" />
              <input
                autoFocus
                autoComplete="off"
                maxLength={60}
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="e.g. Alex Morgan"
                aria-label="Contact name"
                required
              />
            </span>
          </label>
          <button
            className="auth-primary-button"
            type="submit"
            disabled={!name.trim()}
          >
            <MessageCircle size={16} />
            Open private chat
          </button>
        </form>
        <div className="modal-note">
          Messages are saved in this browser in local demo mode.
        </div>
      </section>
    </div>
  );
}
