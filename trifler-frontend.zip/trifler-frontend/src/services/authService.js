import api, { isBackendEnabled } from "./api";

// These route paths are the expected Spring Boot auth endpoints.
export async function registerUser(userData) {
  const { name, email, password } = userData;
  if (!isBackendEnabled) {
    const user = { name: name.trim(), email: email.trim(), isDemo: true };
    console.info("[Trifler auth] Local registration (password omitted)", user);
    return { token: "demo-preview", user };
  }

  const response = await api.post("/auth/register", { name, email, password });
  console.info("[Trifler auth] Registration request completed", { email });
  return response.data;
}

// Passwords are sent only to the configured backend and are never logged.
export async function loginUser(loginData) {
  const { email, password } = loginData;
  if (!isBackendEnabled) {
    const user = {
      name: email.trim().split("@")[0] || "User",
      email: email.trim(),
      isDemo: true,
    };
    console.info("[Trifler auth] Local sign-in (password omitted)", user);
    return { token: "demo-preview", user };
  }

  const response = await api.post("/auth/login", { email, password });
  console.info("[Trifler auth] Sign-in request completed", { email });
  return response.data;
}
