import api, { isBackendEnabled } from "./api";

// Update the current profile using the expected authenticated user route.
export async function updateUserProfile(profile) {
  if (!isBackendEnabled) {
    console.info("[Trifler profile] Local profile update (not sent to a server)", profile);
    return profile;
  }

  const response = await api.patch("/users/me", profile);
  return response.data;
}

// Load the signed-in user's profile when backend mode is enabled.
export async function getCurrentUser() {
  if (!isBackendEnabled) return null;

  const response = await api.get("/users/me");
  return response.data;
}

// Delete the authenticated account when backend mode is enabled.
export async function deleteCurrentUser() {
  if (!isBackendEnabled) {
    console.info("[Trifler account] Local demo account deletion requested.");
    return null;
  }

  const response = await api.delete("/users/me");
  return response.data;
}