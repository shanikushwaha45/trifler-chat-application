import api, { isBackendEnabled } from "./api";

// Fetch persisted conversations when backend mode is enabled.
export async function getConversations() {
  if (!isBackendEnabled) return null;

  const response = await api.get("/conversations");
  return response.data;
}

// The backend route is an integration default and may need to match your API.
export async function createDirectConversation(conversation) {
  if (!isBackendEnabled) return null;

  const response = await api.post("/conversations/direct", {
    name: conversation.name,
    id: conversation.id,
  });
  return response.data;
}
