import { Client } from "@stomp/stompjs";
import { isBackendEnabled } from "./api";

let stompClient = null;
const subscriptions = new Map();

function subscribeDestination(destination) {
  const entry = subscriptions.get(destination);
  if (!entry || !stompClient?.connected) return;

  entry.subscription?.unsubscribe();
  entry.subscription = stompClient.subscribe(destination, (frame) => {
    try {
      entry.onMessage(JSON.parse(frame.body));
    } catch (error) {
      console.error(
        "[Trifler WebSocket] Received invalid message JSON.",
        error,
      );
    }
  });
}

// Connect only when backend mode is explicitly enabled.
export function connectWebSocket({ onStatus } = {}) {
  if (!isBackendEnabled) {
    console.info(
      "[Trifler WebSocket] Backend is disabled; staying in local mode.",
    );
    onStatus?.("offline");
    return null;
  }

  if (stompClient?.active) return stompClient;

  const configuredURL = import.meta.env.VITE_WS_URL || "ws://localhost:8080/ws";
  const brokerURL = configuredURL
    .replace(/^http:/, "ws:")
    .replace(/^https:/, "wss:");
  stompClient = new Client({
    brokerURL,
    reconnectDelay: 5000,
    connectHeaders: localStorage.getItem("chatconnect_token")
      ? { Authorization: `Bearer ${localStorage.getItem("chatconnect_token")}` }
      : {},
    // Avoid protocol debug output because STOMP frames may contain access tokens.
    debug: () => {},
    onConnect: () => {
      console.info("[Trifler WebSocket] Connected", { brokerURL });
      onStatus?.("connected");
      subscriptions.forEach((_entry, destination) => {
        subscribeDestination(destination);
      });
    },
    onDisconnect: () => {
      console.info("[Trifler WebSocket] Disconnected");
      onStatus?.("offline");
    },
    onStompError: (frame) => {
      console.error("[Trifler WebSocket] Broker error", {
        message: frame.headers.message,
        body: frame.body,
      });
      onStatus?.("error");
    },
    onWebSocketError: (event) => {
      console.error("[Trifler WebSocket] Connection error", event);
      onStatus?.("error");
    },
  });

  stompClient.activate();
  onStatus?.("connecting");
  return stompClient;
}

// Subscribe to the documented per-conversation topic when the server supports it.
export function subscribeToConversation(conversationId, onMessage) {
  if (!isBackendEnabled || !conversationId || !onMessage) return () => {};

  const destination = `/topic/conversations/${encodeURIComponent(conversationId)}`;
  subscriptions.set(destination, { onMessage, subscription: null });
  subscribeDestination(destination);

  return () => {
    subscriptions.get(destination)?.subscription?.unsubscribe();
    subscriptions.delete(destination);
  };
}

// Send messages to the server destination configured in the environment.
export function publishMessage(conversationId, message) {
  if (!isBackendEnabled) {
    console.info(
      "[Trifler WebSocket] Message remains local; backend is disabled.",
      {
        conversationId,
        message,
      },
    );
    return false;
  }

  if (!stompClient?.connected) {
    console.error(
      "[Trifler WebSocket] Cannot publish: client is not connected.",
    );
    return false;
  }

  const destination =
    import.meta.env.VITE_WS_SEND_DESTINATION || "/app/chat.send";
  stompClient.publish({
    destination,
    body: JSON.stringify({ conversationId, ...message }),
  });
  return true;
}

// Deactivate the shared connection and remove subscriptions during sign-out.
export async function disconnectWebSocket() {
  subscriptions.forEach((entry) => entry.subscription?.unsubscribe());
  subscriptions.clear();
  if (!stompClient) return;

  await stompClient.deactivate();
  stompClient = null;
}
